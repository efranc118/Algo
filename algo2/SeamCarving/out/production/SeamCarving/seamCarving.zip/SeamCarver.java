import edu.princeton.cs.algs4.*;

import java.awt.*;


public class SeamCarver {

  private double[][] energy;
  private Color[][] colors;
  private boolean isTransposed;

  public SeamCarver(Picture picture) {
    if (picture == null) throw new NullPointerException();
    energy = new double[picture.width()][picture.height()];
    colors = new Color[picture.width()][picture.height()];

    //Initialize Color Array
    for (int i = 0; i < picture.width(); i++) {
      for (int j = 0; j < picture.height(); j++) {
        colors[i][j] = picture.get(i, j);
      }
    }

    //Initialize Energy
    for (int i = 0; i < picture.width(); i++) {
      for (int j = 0; j < picture.height(); j++) {
        if (i == 0 || i == picture.width() - 1 || j == 0 || j == picture.height() - 1) energy[i][j] = 1000;
        else energy[i][j] = calculateEnergy(i, j);
      }
    }
    isTransposed = false;


  }

  private void recalculateEnergy() {
    energy = new double[colors.length][colors[0].length];
    for (int i = 0; i < colors.length; i++) {
      for (int j = 0; j < colors[0].length; j++) {
        if (i == 0 || i == colors.length - 1 || j == 0 || j == colors[0].length - 1) energy[i][j] = 1000;
        else energy[i][j] = calculateEnergy(i, j);
      }
    }
  }

  private double calculateEnergy(int i, int j) {
    Color previousHorizontal = colors[i - 1][j];
    Color nextHorizontal = colors[i + 1][j];
    Color previousVertical = colors[i][j - 1];
    Color nextVertical = colors[i][j + 1];

    double horizontalDifference = getGradientSquared(previousHorizontal, nextHorizontal);
    double verticalDifference = getGradientSquared(previousVertical, nextVertical);
    return Math.sqrt(verticalDifference + horizontalDifference);

  }

  private Double getGradientSquared(Color previous, Color next) {
    double horizontalBlueDifference = previous.getBlue() - next.getBlue();
    double horizontalGreenDifference = previous.getGreen() - next.getGreen();
    double horizontalRedDifference = previous.getRed() - next.getRed();

    return Math.pow(horizontalBlueDifference, 2) + Math.pow(horizontalGreenDifference, 2) + Math.pow(horizontalRedDifference, 2);

  }

  private void transposePicture() {
    double[][] newEnergy = new double[energy[0].length][energy.length];
    Color[][] newColors = new Color[colors[0].length][colors.length];
    for (int i = 0; i < energy.length; i++) {
      for (int j = 0; j < energy[0].length; j++) {
        newEnergy[j][i] = energy[i][j];
        newColors[j][i] = colors[i][j];
      }
    }
    energy = newEnergy;
    colors = newColors;
    isTransposed = !isTransposed;
  }


  public Picture picture() {
    Picture currentPicture = new Picture(colors.length, colors[0].length);
    for (int i = 0; i < colors.length; i++) {
      for (int j = 0; j < colors[0].length; j++) {
        currentPicture.set(i, j, colors[i][j]);
      }
    }
    return currentPicture;
  }

  public int width() {
    return colors.length;
  }

  public int height() {
    return colors[0].length;
  }

  public double energy(int x, int y) {
    if (x < 0 || x >= energy.length || y < 0 || y >= energy[0].length) throw new IndexOutOfBoundsException();
    return energy[x][y];
  }

  public int[] findHorizontalSeam() {
    if (!isTransposed) {
      transposePicture();
    }
    int[] result = findMinSeam();
    if (isTransposed) {
      transposePicture();
    }
    return result;
  }

  public int[] findVerticalSeam() {
    if (isTransposed) {
      transposePicture();
    }
    return findMinSeam();
  }

  private int[] findMinSeam() {
    double[][] minDistTo = new double[energy.length][energy[0].length];
    int[][] pathTo = new int[energy.length][energy[0].length];
    for (int i = 0; i < energy.length; i++) {
      for (int j = 0; j < energy[0].length; j++) {
        minDistTo[i][j] = Double.POSITIVE_INFINITY;
        pathTo[i][j] = -1;
      }
    }

    for (int i = 0; i < energy.length; i++) {
      minDistTo[i][0] = 0;
    }

    for (int i = 0; i < energy[0].length; i++) {
      for (int j = 0; j < energy.length; j++) {
        findSeam(j, i, minDistTo, pathTo);
      }
    }
    double minDist = Double.POSITIVE_INFINITY;
    int path = 0;
    for (int i = 0; i < energy.length; i++) {
      if (minDist > minDistTo[i][energy[0].length - 1]) {
        minDist = minDistTo[i][energy[0].length - 1];
        path = i;
      }
    }

    int[] shortestPath = new int[energy[0].length];
    shortestPath[energy[0].length - 1] = path;
    for (int i = energy[0].length - 2; i >= 0; i--) {
      shortestPath[i] = pathTo[shortestPath[i + 1]][i + 1];
    }

    return shortestPath;
  }


  private void findSeam(int col, int row, double[][] minDistTo, int[][] pathTo) {
    if (row + 1 < energy[0].length) {
      double currentEnergy = minDistTo[col][row] + energy[col][row];
      for (int i = -1; i < 2; i++) {
        if (col + i >= 0 && col + i < energy.length) {
          if (minDistTo[col + i][row + 1] > energy[col + i][row + 1] + currentEnergy) {
            minDistTo[col + i][row + 1] = energy[col + i][row + 1] + currentEnergy;
            pathTo[col + i][row + 1] = col;
          }
        }
      }
    }
  }


  public void removeHorizontalSeam(int[] seam) {
    if (isTransposed) transposePicture();
    Color[][] updatedPicture = new Color[energy.length][energy[0].length - 1];

    for (int i = 0; i < energy.length; i++) {
      int removedPixel = seam[i];
      System.arraycopy(colors[i], 0, updatedPicture[i], 0, removedPixel);
      System.arraycopy(colors[i], removedPixel + 1, updatedPicture[i], removedPixel, (energy[i].length - 1) - removedPixel);
    }

    colors = updatedPicture;
    recalculateEnergy();

  }

  public void removeVerticalSeam(int[] seam) {

    if (!isTransposed) transposePicture();
    Color[][] updatedPicture = new Color[energy.length][energy[0].length - 1];

    for (int i = 0; i < energy.length; i++) {
      int removedPixel = seam[i];
      System.arraycopy(colors[i], 0, updatedPicture[i], 0, removedPixel);
      System.arraycopy(colors[i], removedPixel + 1, updatedPicture[i], removedPixel, (energy[i].length - 1) - removedPixel);
    }

    colors = updatedPicture;
    recalculateEnergy();
    if (isTransposed) transposePicture();
  }

}



